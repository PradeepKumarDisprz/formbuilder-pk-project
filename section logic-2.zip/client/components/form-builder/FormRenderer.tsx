import { useState } from "react";
import {
  FormSchema,
  FormField,
  FormItem,
  DropdownProperties,
  DatePickerProperties,
  FileUploadProperties,
  isFormField,
  isFormSection,
  getAllFields,
} from "@/lib/form-schema";
import { validateForm, ValidationResult } from "@/lib/form-validation";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Upload, X } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import styles from "./FormRenderer.module.scss";

interface FormRendererProps {
  schema: FormSchema;
  values?: Record<string, any>;
  onValuesChange?: (values: Record<string, any>) => void;
  onSubmit?: (
    values: Record<string, any>,
    validation: ValidationResult,
  ) => void;
  mode?: "preview" | "response";
  className?: string;
}

export const FormRenderer: React.FC<FormRendererProps> = ({
  schema,
  values = {},
  onValuesChange,
  onSubmit,
  mode = "response",
  className,
}) => {
  const [formValues, setFormValues] = useState<Record<string, any>>(values);
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string>
  >({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const updateValue = (fieldId: string, value: any) => {
    const newValues = { ...formValues, [fieldId]: value };
    setFormValues(newValues);
    onValuesChange?.(newValues);

    // Clear validation error for this field
    if (validationErrors[fieldId]) {
      setValidationErrors((prev) => {
        const { [fieldId]: _, ...rest } = prev;
        return rest;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Create a temporary schema with sections for validation
    const tempSchema = {
      ...schema,
      sections: [
        {
          id: "temp",
          title: "Form",
          description: "",
          fields: getAllFields(schema.items),
          order: 0,
        },
      ],
    };

    const validation = validateForm(tempSchema, formValues);

    if (!validation.isValid) {
      const errorMap: Record<string, string> = {};
      validation.errors.forEach((error) => {
        errorMap[error.fieldId] = error.message;
      });
      setValidationErrors(errorMap);
    } else {
      setValidationErrors({});
    }

    onSubmit?.(formValues, validation);
    setIsSubmitting(false);
  };

  const renderField = (field: FormField, questionNumber?: number) => {
    const fieldValue = formValues[field.id];
    const hasError = !!validationErrors[field.id];
    const isUDF = field.type.startsWith("udf-");

    const fieldWrapper = (children: React.ReactNode) => (
      <div className={styles.fieldContainer}>
        <Label
          className={cn(
            styles.fieldLabel,
            hasError && styles.hasError,
            "text-sm font-medium text-gray-900",
          )}
        >
          {questionNumber && (
            <span className="mr-2 text-gray-500">{questionNumber}.</span>
          )}
          {field.label}
          {field.required && (
            <span className={styles.requiredIndicator}>*</span>
          )}
        </Label>
        {field.showDescription && field.description && (
          <p className={styles.fieldDescription}>{field.description}</p>
        )}
        {children}
        {hasError && (
          <p className={styles.fieldError}>{validationErrors[field.id]}</p>
        )}
      </div>
    );

    if (isUDF) {
      return fieldWrapper(
        <Input
          value=""
          disabled
          placeholder={`${field.label} (auto-filled from user data)`}
          className={cn(styles.fieldInput, styles.udfField)}
        />,
      );
    }

    switch (field.type) {
      case "short-text":
        return fieldWrapper(
          <Input
            value={fieldValue || ""}
            onChange={(e) => updateValue(field.id, e.target.value)}
            placeholder={(field.properties as any).placeholder}
            className={cn(
              styles.fieldInput,
              hasError && styles.hasError,
              "mt-1",
            )}
          />,
        );

      case "long-text":
        return fieldWrapper(
          <Textarea
            value={fieldValue || ""}
            onChange={(e) => updateValue(field.id, e.target.value)}
            placeholder={(field.properties as any).placeholder}
            rows={4}
            className={cn(
              styles.fieldInput,
              hasError && styles.hasError,
              "mt-1",
            )}
          />,
        );

      case "number":
        return fieldWrapper(
          <Input
            type="number"
            value={fieldValue || ""}
            onChange={(e) => updateValue(field.id, e.target.value)}
            placeholder={(field.properties as any).placeholder}
            min={(field.properties as any).min}
            max={(field.properties as any).max}
            step={(field.properties as any).step}
            className={cn(
              styles.fieldInput,
              hasError && styles.hasError,
              "mt-1",
            )}
          />,
        );

      case "date-picker":
        const dateProps = field.properties as DatePickerProperties;
        return fieldWrapper(
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  styles.datePickerButton,
                  "w-full justify-start text-left font-normal mt-1",
                  !fieldValue && !styles.hasValue,
                  hasError && styles.hasError,
                )}
              >
                <CalendarIcon className={styles.dateIcon} />
                {fieldValue
                  ? format(new Date(fieldValue), "PPP")
                  : "Pick a date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={fieldValue ? new Date(fieldValue) : undefined}
                onSelect={(date) => updateValue(field.id, date?.toISOString())}
                initialFocus
              />
            </PopoverContent>
          </Popover>,
        );

      case "dropdown":
        const dropdownProps = field.properties as DropdownProperties;

        if (dropdownProps.selectionType === "multi") {
          return fieldWrapper(
            <div className={cn(styles.checkboxContainer, "mt-1")}>
              {dropdownProps.options?.map((option) => (
                <div key={option.id} className={styles.checkboxItem}>
                  <Checkbox
                    id={`${field.id}-${option.id}`}
                    checked={
                      Array.isArray(fieldValue) &&
                      fieldValue.includes(option.value)
                    }
                    onCheckedChange={(checked) => {
                      const currentValues = Array.isArray(fieldValue)
                        ? fieldValue
                        : [];
                      if (checked) {
                        updateValue(field.id, [...currentValues, option.value]);
                      } else {
                        updateValue(
                          field.id,
                          currentValues.filter((v) => v !== option.value),
                        );
                      }
                    }}
                  />
                  <Label
                    htmlFor={`${field.id}-${option.id}`}
                    className={styles.checkboxLabel}
                  >
                    {option.label}
                  </Label>
                </div>
              ))}
            </div>,
          );
        } else {
          return fieldWrapper(
            <Select
              value={fieldValue || ""}
              onValueChange={(value) => updateValue(field.id, value)}
            >
              <SelectTrigger
                className={cn(
                  "mt-1",
                  hasError && "border-red-300 focus:border-red-500",
                )}
              >
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                {dropdownProps.options?.map((option) => (
                  <SelectItem key={option.id} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>,
          );
        }

      case "file-upload":
        const fileProps = field.properties as FileUploadProperties;
        return fieldWrapper(
          <div className={cn(styles.fileUpload, "mt-1")}>
            <div className={styles.fileUploadArea}>
              <input
                type="file"
                id={`file-${field.id}`}
                multiple={fileProps.multiple}
                accept={fileProps.acceptedTypes?.join(",")}
                onChange={(e) => {
                  const files = e.target.files;
                  if (files) {
                    updateValue(
                      field.id,
                      fileProps.multiple ? Array.from(files) : files[0],
                    );
                  }
                }}
                className={styles.hiddenFileInput}
              />
              <Label
                htmlFor={`file-${field.id}`}
                className={styles.fileUploadLabel}
              >
                <Upload className={styles.uploadIcon} />
                <p className={styles.fileUploadText}>
                  Click to upload {fileProps.multiple ? "files" : "a file"}
                </p>
                {fileProps.acceptedTypes && (
                  <p className={styles.fileUploadHint}>
                    Accepted: {fileProps.acceptedTypes.join(", ")}
                  </p>
                )}
              </Label>
            </div>
            {fieldValue && (
              <div className={styles.fileSelectedText}>
                {Array.isArray(fieldValue)
                  ? `${fieldValue.length} file(s) selected`
                  : fieldValue.name || "File selected"}
              </div>
            )}
          </div>,
        );

      default:
        return fieldWrapper(
          <Input
            value={fieldValue || ""}
            onChange={(e) => updateValue(field.id, e.target.value)}
            placeholder="Enter value"
            className={cn(styles.fieldInput, "mt-1")}
          />,
        );
    }
  };

  const hasAnySections = schema.items.some((item) => isFormSection(item));
  let questionCounter = 1;

  return (
    <div className={cn(styles.formRenderer, className)}>
      <form onSubmit={handleSubmit} className={styles.form}>
        {/* Form Header */}
        <div className={styles.formHeader}>
          <h1 className={styles.formTitle}>{schema.title}</h1>
          {schema.description && (
            <p className={styles.formDescription}>{schema.description}</p>
          )}
        </div>

        {/* Form Content */}
        {hasAnySections ? (
          // Render with sections
          <div className={styles.sectionsContainer}>
            {schema.items.map((item) => {
              if (isFormField(item)) {
                // Standalone field
                return (
                  <div key={item.id} className="mb-6">
                    {renderField(item, questionCounter++)}
                  </div>
                );
              } else {
                // Section
                return (
                  <div key={item.id} className={styles.section}>
                    <div className={styles.sectionHeader}>
                      <div className="bg-indigo-600 text-white px-4 py-2 rounded-t-lg">
                        <span className="text-sm font-medium">
                          Section {item.order + 1} of{" "}
                          {schema.items.filter((i) => isFormSection(i)).length}
                        </span>
                      </div>
                      <div className="bg-white border border-t-0 border-gray-200 px-6 py-4">
                        <h2 className={styles.sectionTitle}>{item.title}</h2>
                        {item.description && (
                          <p className={styles.sectionDescription}>
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="bg-white border border-t-0 border-gray-200 rounded-b-lg p-6">
                      <div className={styles.fieldsContainer}>
                        {item.fields.map((field) => (
                          <div key={field.id}>
                            {renderField(field, questionCounter++)}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              }
            })}
          </div>
        ) : (
          // Render without sections - clean layout
          <div className="bg-white rounded-lg border border-gray-200 p-8">
            <div className={styles.fieldsContainer}>
              {schema.items.map((item) => {
                if (isFormField(item)) {
                  return (
                    <div key={item.id}>
                      {renderField(item, questionCounter++)}
                    </div>
                  );
                }
                return null;
              })}
            </div>
          </div>
        )}

        {/* Submit Button */}
        {mode === "response" && (
          <div className={styles.submitContainer}>
            <Button
              type="submit"
              disabled={isSubmitting}
              className={styles.submitButton}
            >
              {isSubmitting ? "Submitting..." : "Submit"}
            </Button>
          </div>
        )}
      </form>
    </div>
  );
};
